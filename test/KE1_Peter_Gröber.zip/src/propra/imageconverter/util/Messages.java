package propra.imageconverter.util;

/**
 * 
 * @author pg
 * @param <MsgID> 
 */
public interface Messages {    
    /**
     * 
     * @param mID
     * @return 
     */
    public String getMessage(MessageID mID);
}
