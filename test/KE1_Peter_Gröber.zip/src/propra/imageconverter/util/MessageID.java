package propra.imageconverter.util;

/**
 *
 * @author pg
 */
public enum MessageID {
    MID_OK,
    MID_UNSUPPORTED,
}
